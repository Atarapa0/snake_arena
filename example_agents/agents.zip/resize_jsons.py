import os

json_names = {
    'ahmet': 'ahmet_params.json',
    'mehmet': 'mehmet_params.json',
    'zeynep': 'zeynep_weights.json',
    'veli': 'veli_params.json',
    'ayse': 'ayse_params.json',
    'fatma': 'fatma_weights.json',
    'can': 'can_params.json',
    'canan': 'canan_params.json',
    'deniz': 'deniz_params.json',
    'murat': 'murat_weights.json',
    'elif': 'elif_params.json',
    'cem': 'cem_params.json',
    'eda': 'eda_weights.json',
    'alp': 'alp_params.json',
}

sizes_mb = {
    'ahmet': 20.0,   # Tam 20 MB
    'mehmet': 22.0,  # 20 MB'den büyük
    'zeynep': 25.0,  # 20 MB'den büyük
    'veli': 2.0,
    'ayse': 3.0,
    'fatma': 4.0,
    'can': 5.0,
    'canan': 6.0,
    'deniz': 7.5,
    'murat': 8.0,
    'elif': 9.2,
    'cem': 10.0,
    'eda': 15.0,
    'alp': 19.9,
}

for ag, filename in json_names.items():
    filepath = os.path.join('example_agents', filename)
    target_size = int(sizes_mb[ag] * 1024 * 1024)
    
    content = b"{}"
    if os.path.exists(filepath):
        with open(filepath, 'rb') as f:
            content = f.read()
            if not content.strip():
                content = b"{}"
    
    if len(content) < target_size:
        padding = b" " * (target_size - len(content))
        content += padding
    else:
        # Eğer dosya gereğinden büyükse veya JSON bozmadan ufaltmak istersek
        content = content[:target_size]
    
    with open(filepath, 'wb') as f:
        f.write(content)
    
    print(f"Updated {filename}: {os.path.getsize(filepath) / (1024*1024):.2f} MB")
